// ==UserScript==
// @name         去除百度搜索、百度文库、百度贴吧、百度百科、百度图片、百度视频、百度知道、百度地图、百度经验、百度翻译的广告
// @namespace    baidu_clear_ad
// @version      1.1.1.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author       liupan
// @match      *://item.taobao.com/*
// @match      *://*detail.tmall.com/*
// @match      *://*detail.tmall.hk/*
// @match        *://*.taobao.com/*
// @match        *://*.tmall.com/*
// @match        *://*.tmall.hk/*
// @match      *://*.liangxinyao.com/*
// @match        *://*.taobao.com/*
// @match        *://*.tmall.com/*
// @match        *://*.tmall.hk/*
// @match        *://*.jd.com/*
// @match        *://*.jd.hk/*
// @match        *://*.liangxinyao.com/*
// @exclude       *://login.taobao.com/*
// @exclude       *://pages.tmall.com/*
// @exclude       *://uland.taobao.com
// @match        *://*.baidu.com/*
// @grant        none
// ==/UserScript==
