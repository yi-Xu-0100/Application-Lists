// ==UserScript==
// @name         中国知网CNKI硕博论文PDF下载
// @version      0.2.3
// @description  add PDF download button to CNKI.
// @author       leftjie
// @include        http*://*/kcms/detail/detail.aspx?dbcode=CMFD*
// @include        http*://*/kcms/detail/detail.aspx?dbcode=CDFD*
// @include        http*://*/KCMS/detail/detail.aspx?dbcode=CMFD*
// @include        http*://*/KCMS/detail/detail.aspx?dbcode=CDFD*
// @match        http*://kns.cnki.net/kcms/detail/detail.aspx?dbcode=CMFD*
// @match        http*://kns.cnki.net/kcms/detail/detail.aspx?dbcode=CDFD*
// @match        http*://kns.cnki.net/KCMS/detail/detail.aspx?dbcode=CMFD*
// @match        http*://kns.cnki.net/KCMS/detail/detail.aspx?dbcode=CDFD*
// @grant        none
// @namespace https://greasyfork.org/users/244539
// ==/UserScript==

(function() {
    'use strict';
    window.onload = function(){
        var url = window.location.href;
        var dllink = document.getElementsByClassName('btn-dlcaj');
        for (var i = dllink.length - 1; i >= 0; i--) {
            var nhdown = dllink[i].getElementsByTagName('a');
            var dl = nhdown[0].href.replace('dflag=nhdown','dflag=pdfdown')
            var a = document.createElement('a');
            //a.className = "icon icon-dlGreen";
            a.innerText = "PDF 下载";
            a.href = dl;
            a.style.width="135px";
            a.style.display="inline-block";
            a.style.lineHeight="40px";
            a.style.borderRadius="5px";
            a.style.backgroundColor="#fb4376";
            a.style.color="white";
            a.style.fontSize="16px";
            a.style.verticalAlign="middle";
            a.style.textAlign="center";
            a.style.fontFamily="Microfost Yahei,Arial";
            document.getElementsByClassName('btn-dlcaj')[i].appendChild(a);
        }
    };
})();