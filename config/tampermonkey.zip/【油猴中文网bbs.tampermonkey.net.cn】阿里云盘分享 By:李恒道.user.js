// ==UserScript==
// @name         【油猴中文网bbs.tampermonkey.net.cn】阿里云盘分享 By:李恒道
// @namespace    https://bbs.tampermonkey.net.cn/thread-280-1-1.html
// @version      1.0
// @description  【油猴中文网bbs.tampermonkey.net.cn】阿里云盘分享 By:李恒道
// @author       李恒道
// @match        https://www.aliyundrive.com/*
// @match        https://passport.aliyundrive.com/*
// @match        https://aliyundrive.com/*
// @match        https://passport.aliyundrive.com/*
// @grant        unsafeWindow
// @grant        GM_setClipboard
// @grant        GM_xmlhttpRequest
// @connect      aliyundrive.com
// @supportURL   https://bbs.tampermonkey.net.cn/forum.php?mod=viewthread&tid=280
// @homepage     https://bbs.tampermonkey.net.cn/forum.php?mod=viewthread&tid=280
// ==/UserScript==
let username=''
let password=''
if(unsafeWindow.location.href.indexOf('passport.aliyundrive.com/mini_login')!=-1)
{
    if(username!='')
    {
    unsafeWindow.setInterval(function () {
        if(document.querySelector('.login-blocks a')==null)
        {
        return;}
        document.querySelector('.login-blocks a').click()
        document.querySelector('#fm-login-id').value=username
        document.querySelector('#fm-login-password').value=password
        document.querySelector('.password-login').click()
    },1000)

    }
}
else{
var HookFileStatus=false;
var ShowFileObj={
    name:'文件获取失败',
    content_hash:'hash获取失败',
    size:'公众号:叛逆青年旅舍，来自油猴中文网:bbs.tampermonkey.net.cn',
    content_type:'Fucccccck'
}
var Fileid=''
var content_type=''
function GenerateSaveBtn(){

    let TempHtml=document.querySelector('.toolbar')
    if(TempHtml==null)
    {
        return;
    }
    let parentdom=TempHtml
    TempHtml=TempHtml.innerHTML
    if(TempHtml.indexOf('提取文件')==-1)
    {
                    let savebtn=document.createElement("div");
        savebtn.innerHTML='<a data-v-5cb4f846="" data-v-2ebc3d34="" class="btn relative small primary " style="z-index: 2;"><!----><span data-v-2ebc3d34="" data-v-5cb4f846="">提取文件</span><input data-v-2ebc3d34="" data-v-5cb4f846="" multiple="multiple" type="file" class="d-none"><input data-v-2ebc3d34="" data-v-5cb4f846="" webkitdirectory="" directory="" type="file" class="d-none"><!----></a>';
        savebtn.onclick=function(){

          var text=prompt("请输入分享码","");
            text=decodeURIComponent(escape(window.atob(text)))
            text=JSON.parse(text)
            if(text.content_hash==undefined)
            {
                alert('提取码不正确！')
            }
            else{
                let useruid=unsafeWindow.VueApp.myInfo.default_drive_id
                let uploadtext='{"name":"'+text.name+'","type":"file","content_type":"'+text.content_type+'","size":'+text.size+',"drive_id":"'+useruid+'","parent_file_id":"root","part_info_list":[{"part_number":1}],"content_hash_name":"sha1","content_hash":"'+text.content_hash+'","ignoreError":false,"check_name_mode":"auto_rename"}'
                console.log('上传文本',uploadtext)
                let auth=JSON.parse(unsafeWindow.localStorage.getItem('token')).access_token
                GM_xmlhttpRequest({
        url:"https://api.aliyundrive.com/v2/file/create",
        method :"POST",
        data:uploadtext,
        headers: {
            "Content-type": "application/json;charset=utf-8",
            "Authorization": auth
        },
        onload:function(xhr){
           var json = JSON.parse(xhr.responseText);
            console.log('获取成功！',json);
            if(json.rapid_upload==true)
            {
            alert("提取文件成功！")
                unsafeWindow.location.reload();
            }
            else{
                alert("提取文件失败！")
            }
        }
    });

            }
        }
            parentdom.appendChild(savebtn);

    }
}
function HookFileInfo(){
    if(HookFileStatus==true)
    {
        return;
    }
    let element=unsafeWindow.VueApp.$children[0].$children[0].$children[8]
    if(element!=null){
        HookFileStatus=true;
        let oldfile=unsafeWindow.VueApp.$children[0].$children[0].$children[8].getInfo
        unsafeWindow.VueApp.$children[0].$children[0].$children[8].getInfo=function(e){
        console.log('劫持函数',e)
            ShowFileObj.name=e.name
            ShowFileObj.content_hash=e.content_hash
            ShowFileObj.size=e.size
            ShowFileObj.content_type=e.content_type
            Fileid=e.file_id
            content_type=e.content_type
            oldfile(e)
    }
    }
}
function CheckDetailDialog(){

    let TempHtml=document.querySelector('.dialog')
    if(TempHtml==null)
    {
        return;
    }
    TempHtml=TempHtml.innerHTML
    if(TempHtml.indexOf('详细信息')!=-1)
    {
        if(TempHtml.indexOf('分享文件')==-1)
        {
        let sharebtn=document.createElement("span");
        sharebtn.innerHTML='<a data-v-5cb4f846="" data-v-2ebc3d34="" class="btn relative small primary " style="z-index: 2;"><!----><span data-v-2ebc3d34="" data-v-5cb4f846="">分享文件</span><input data-v-2ebc3d34="" data-v-5cb4f846="" multiple="multiple" type="file" class="d-none"><input data-v-2ebc3d34="" data-v-5cb4f846="" webkitdirectory="" directory="" type="file" class="d-none"><!----></a>';
        sharebtn.onclick=function(){
            //点击了按钮
            /*            ShowFileObj.name=e.name
            ShowFileObj.content_hash=e.content_hash
            ShowFileObj.size=e.size*/
            let ret=confirm('文件名:'+ShowFileObj.name+'\n校验值:'+ShowFileObj.content_hash+'\n文件大小:'+ShowFileObj.size+'\n'+
                  '点击确定自动添加分享码到剪辑版\n来自油猴中文网bbs.tampermonkey.net.cn\n公众号:叛逆青年旅舍');
            if(ret==true)
            {
                console.log('设置剪辑版',JSON.stringify(ShowFileObj))
                try
                {
                    GM_setClipboard(window.btoa(unescape(encodeURIComponent(JSON.stringify(ShowFileObj)))))
                }
                catch(err)
                {

                    alert('文件名字可能存在特殊关键字，请改名重试')
                }

            }
        }
        document.querySelector('.dialog ul').appendChild(sharebtn);



       if(content_type=="video/mp4")
       {
                    let getvideourl=document.createElement("span");
        getvideourl.style.paddingLeft='10px'
        getvideourl.innerHTML='<a data-v-5cb4f846=""  data-v-2ebc3d34="" class="btn relative small primary " style="z-index: 2;"><!----><span data-v-2ebc3d34="" data-v-5cb4f846="">解析视频</span><input data-v-2ebc3d34="" data-v-5cb4f846="" multiple="multiple" type="file" class="d-none"><input data-v-2ebc3d34="" data-v-5cb4f846="" webkitdirectory="" directory="" type="file" class="d-none"><!----></a>';
        getvideourl.onclick=function(){
          console.log('getvideourl')

                let useruid=unsafeWindow.VueApp.myInfo.default_drive_id
                let uploadtext='{"drive_id":"'+useruid+'","file_id":"'+Fileid+'"}'
                let auth=JSON.parse(unsafeWindow.localStorage.getItem('token')).access_token
                GM_xmlhttpRequest({
        url:"https://api.aliyundrive.com/v2/databox/get_video_play_info",
        method :"POST",
        data:uploadtext,
        headers: {
            "Content-type": "application/json;charset=utf-8",
            "Authorization": auth
        },
        onload:function(xhr){
           var json = JSON.parse(xhr.responseText);

            if(json.template_list!=undefined)
            {

                var text=prompt("请输入视频质量数字\n本视频最小[0]-最大["+(json.template_list.length-1)+"]数字越大解析质量越高:","")
                GM_setClipboard(json.template_list[parseInt(text)].url)
                alert('获取视频成功!已复制到剪辑版！\n注意:视频仅短期有效')
            }
            else{
                alert('获取视频失败!')

            }
        }
    });
        }
       document.querySelector('.dialog ul').appendChild(getvideourl);
       }


         let download=document.createElement("span");
        download.style.paddingLeft='10px'
        download.innerHTML='<a data-v-5cb4f846=""  data-v-2ebc3d34="" class="btn relative small primary " style="z-index: 2;"><!----><span data-v-2ebc3d34="" data-v-5cb4f846="">解析下载</span><input data-v-2ebc3d34="" data-v-5cb4f846="" multiple="multiple" type="file" class="d-none"><input data-v-2ebc3d34="" data-v-5cb4f846="" webkitdirectory="" directory="" type="file" class="d-none"><!----></a>';
        download.onclick=function(){
          console.log('getvideourl')

                let useruid=unsafeWindow.VueApp.myInfo.default_drive_id
                let uploadtext='{"drive_id":"'+useruid+'","file_id":"'+Fileid+'","file_name":"'+ShowFileObj.name+'","expire_sec":7200}'
                let auth=JSON.parse(unsafeWindow.localStorage.getItem('token')).access_token
                GM_xmlhttpRequest({
        url:"https://api.aliyundrive.com/v2/file/get_download_url",
        method :"POST",
        data:uploadtext,
        headers: {
            "Content-type": "application/json;charset=utf-8",
            "Authorization": auth
        },
        onload:function(xhr){
           var json = JSON.parse(xhr.responseText);

            if(json.url!=undefined)
            {

                GM_setClipboard(json.url)
                alert('获取解析链接!已复制到剪辑版！')
            }
            else{
                alert('获取解析链接失败!\n注意:链接仅短期有效')

            }
        }
    });
        }
       document.querySelector('.dialog ul').appendChild(download);



            
        }

    }
}

    unsafeWindow.addEventListener('DOMNodeInserted',function () {
       CheckDetailDialog()
       HookFileInfo()
       GenerateSaveBtn()
    })


}







